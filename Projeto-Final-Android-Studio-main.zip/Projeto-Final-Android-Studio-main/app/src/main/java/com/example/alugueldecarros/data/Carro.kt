package com.example.alugueldecarros.data

data class Carro(val id: Int, val foto:String, val nome:String, val preco: Float, val ano: Int) {


}