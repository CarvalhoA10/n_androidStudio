package com.example.alugueldecarros

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.alugueldecarros.api.RetrofitClient
import com.example.alugueldecarros.api.SessionManage
import com.example.alugueldecarros.data.User
import kotlinx.coroutines.launch

class Register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val username = findViewById<EditText>(R.id.usernameC)
        val password = findViewById<EditText>(R.id.passwordC)
        val telefone = findViewById<EditText>(R.id.telefoneC)
        val email = findViewById<EditText>(R.id.emailC)

        val btn_cadastrar = findViewById<Button>(R.id.btn_cadastra)

        btn_cadastrar.setOnClickListener {

            lifecycleScope.launch {

                try {

                    var user = User(username.text.toString(), email.text.toString(), password.text.toString())

                    var response = RetrofitClient.instance.cadastrarUsuario(user)

                    val intent = Intent(this@Register, MainActivity::class.java)
                    startActivity(intent)

                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("API_ERROR", "Erro ao carregar carros: ${e.message}")
                    Toast.makeText(this@Register, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

        }

    }
}