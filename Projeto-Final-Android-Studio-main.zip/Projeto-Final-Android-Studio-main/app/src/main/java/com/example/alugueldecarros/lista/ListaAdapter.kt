package com.example.alugueldecarros.lista

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.alugueldecarros.R
import com.example.alugueldecarros.Veiculo
import com.example.alugueldecarros.data.Carro

class ListaAdapter (var itens : List<Carro>) : RecyclerView.Adapter<ListaAdapter.ItemViewHolder>() {

    class ItemViewHolder(carditem : View ) : RecyclerView.ViewHolder(carditem){
        val img = carditem.findViewById<ImageView>(R.id.img_carro_a)
        val nome = carditem.findViewById<TextView>(R.id.txt_nome_veiculo)
        val valor = carditem.findViewById<TextView>(R.id.txt_preco_dia)
        val btn_vermais = carditem.findViewById<Button>(R.id.btn_vermais)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListaAdapter.ItemViewHolder {
        val lista = LayoutInflater.from(parent.context)
            .inflate(R.layout.carro_aluguel, parent, false)
        return ItemViewHolder(lista)
    }

    override fun onBindViewHolder(holder: ListaAdapter.ItemViewHolder, position: Int) {
        holder.nome.text = itens[position].nome
        holder.valor.text = itens[position].preco.toString()
        val url = "https://aelson.pythonanywhere.com".plus(itens[position].foto.toString())
        Glide.with(holder.img.context)
            .load(url)
            .into(holder.img)

        holder.btn_vermais.setOnClickListener {
            val intent = Intent(holder.itemView.context, Veiculo::class.java)
            intent.putExtra("id", itens[position].id)

            holder.itemView.context.startActivity(intent)
        }
    }

    fun atualizarDados(novosItens: List<Carro>) {
        this.itens = novosItens
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return this.itens.size
    }

}