package com.example.alugueldecarros.api

object SessionManage {
    var token: String = ""
}