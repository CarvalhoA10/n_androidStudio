package com.example.alugueldecarros.api

data class LoginResponse(
    val refresh: String,
    val access: String
)