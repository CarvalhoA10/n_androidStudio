package com.example.alugueldecarros.lista

class VeiculoModel(var nome: String, var preco: String, var img: String, var id: String) {
}