package com.example.alugueldecarros

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.alugueldecarros.api.RetrofitClient
import com.example.alugueldecarros.api.SessionManage
import com.example.alugueldecarros.lista.ListAlugado
import com.example.alugueldecarros.lista.ListaAdapter
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.launch

class MeusCarros : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_meus_carros)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        lifecycleScope.launch {
            try {
                val carros = RetrofitClient.instance.meusCarros("Bearer ".plus(SessionManage.token))

                print(carros.get(0))

                // ✅ Agora os dados estão carregados, então configuramos o RecyclerView
                val listaAdapter = ListAlugado(carros)

                val listView = findViewById<RecyclerView>(R.id.recycle_item)
                listView.layoutManager = LinearLayoutManager(this@MeusCarros)
                listView.adapter = listaAdapter

            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("API_ERROR", "Erro ao carregar carros: ${e.message}")
                Toast.makeText(this@MeusCarros, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        var botton_navigation : BottomNavigationView = findViewById<BottomNavigationView>(R.id.botton_navigation_bar)

        botton_navigation.selectedItemId = R.id.img_carro

        botton_navigation.setOnItemSelectedListener {
            when(it.itemId){
                R.id.img_home -> {
                    val intent = Intent(this, PaginaInicial::class.java)
                    startActivity(intent)
                    true
                }
                R.id.img_carro -> {
                    val intent = Intent(this, MeusCarros::class.java)
                    startActivity(intent)
                    true
                }
                R.id.img_pessoa -> {
                    val intent = Intent(this, Usuario::class.java)
                    startActivity(intent)
                    true
                }

                R.id.img_sair -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    true
                }

                else -> false
            }
        }
    }
}