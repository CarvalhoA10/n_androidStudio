package com.example.alugueldecarros

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.alugueldecarros.api.LoginRequest
import com.example.alugueldecarros.api.RetrofitClient
import com.example.alugueldecarros.api.SessionManage
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

class Veiculo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_veiculo)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        var veiculo_img = findViewById<ImageView>(R.id.img_foto_carro)
        var veiculo_name = findViewById<TextView>(R.id.txt_nome_veiculo)
        var veiculo_preco = findViewById<TextView>(R.id.txt_valor_dia)
        var veiculo_km = findViewById<TextView>(R.id.txt_km)
        var btn_alugar = findViewById<MaterialButton>(R.id.btn_alugar_carro)

        lifecycleScope.launch {

            try {

                val id = intent.getIntExtra("id", -1)

                var response =
                    RetrofitClient.instance.getCarro(id, "Bearer ".plus(SessionManage.token))

                val imageUrl = "https://aelson.pythonanywhere.com${response.foto}"
                Glide.with(this@Veiculo)
                    .load(imageUrl)
                    .into(veiculo_img)

                veiculo_name.text = response.nome
                veiculo_preco.text = "R$ ${response.preco}"
                //veiculo_km.text = "${response.km} km"

            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("API_ERROR", "Erro ao carregar carros: ${e.message}")
                Toast.makeText(this@Veiculo, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
            }

        }

        btn_alugar.setOnClickListener {
            lifecycleScope.launch {

                try {

                    val id = intent.getIntExtra("id", -1)

                    var response =
                        RetrofitClient.instance.devolverCarro(id, "Bearer ".plus(SessionManage.token))

                    val intent = Intent(this@Veiculo, MeusCarros::class.java)
                    startActivity(intent)

                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("API_ERROR", "Erro ao carregar carros: ${e.message}")
                    Toast.makeText(this@Veiculo, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}