package com.example.alugueldecarros.api

import com.example.alugueldecarros.data.Carro
import com.example.alugueldecarros.data.User
import okhttp3.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {

    @POST("api/cadastrar/")
    suspend fun cadastrarUsuario(@Body usuario: User): retrofit2.Response<Void>

    @GET("carros")
    suspend fun getCarros(@Header("Authorization") token: String): List<Carro>

    @POST("api/token/")
    suspend fun login(@Body request: LoginRequest): LoginResponse

    @GET("carro/{id}/")
    suspend fun getCarro(@Path("id") id: Int, @Header("Authorization") token: String): Carro

    @POST("carro/devolver/{id}")
    suspend fun devolverCarro(@Path("id") id: Int, @Header("Authorization") token: String): retrofit2.Response<Void>

    @POST("carro/alugar/{id}")
    suspend fun alugarCarro(@Path("id") id: Int, @Header("Authorization") token: String): retrofit2.Response<Void>

    @GET("meuscarros")
    suspend fun meusCarros(@Header("Authorization") token: String): List<Carro>
}