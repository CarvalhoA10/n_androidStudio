package com.example.alugueldecarros.api

data class LoginRequest(
    val username: String,
    val password: String
)