package com.example.alugueldecarros.data

data class User(var username: String, var email: String, var password: String){}
